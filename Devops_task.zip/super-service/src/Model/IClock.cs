using System;

public interface IClock
{
  DateTime GetNow();
}